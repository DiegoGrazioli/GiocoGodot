# GiocoGodot

#### Ce la faremo a finire in tempo?

## Features:
- Combattimento:
	> Attacco basato su tipo arma

	> Velocità attacco basata su tipo arma

	> Velocità di attacco in movimento basata su peso arma

- Item:
	> Gli item all'interno delle chest sono randomici, ma si può decidere quali includere

## Implementazioni desiderate:
- Colore particelle basato su rarità arma (aggiungere variabile colore ad ogni struct item)
- Statistiche level-based
- NPCs
- Mercato per ottenere item
- Inventario
- Pausa
- Main menu
- Impostazioni
- Salvataggio
- Altri item (armatura, pozioni, ...)
- Audio?

## Promemoria
- Dash cambia in SHIFT
- Scudo diventa RMB
- Utilizzo oggetti LMB
- Non esiste inventario, puoi modificare oggetti dal deposito
- Possibili metodi di cura:
	> Fontana revitalizzante
	
	> Rigenerazione passiva
	
	> Tramite pozioni
